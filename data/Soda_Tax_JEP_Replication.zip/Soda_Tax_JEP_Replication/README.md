# Readme

This is the replication file for Allcott, Lockwood, and Taubinsky: Should We Tax Sugar-Sweetened Beverages? An Overview of Theory and Evidence

The contents of this folder can be used to produce figures and many of the numbers reported in the text of the final paper. 

## Folder contents

The key files and scripts for replication are as follows:

* Code/
	* OptimalSodaTax_JEPMasterFile.do: this is the primary script, which can be run in Stata, and which calls all other necessary scripts for replication. 
	* Build/: contains other scripts which clean and format data. 
	* Analaysis/: contains other scripts which analyze data and export figures and results.
* Externals/
	* Data/: contains all raw data necessary for replication, from NHANES (see paper), along with a text file with further information.
	* Intermediate/: empty -- filled with intermediate data files when script executes.
* Output/: contains nothing but empty subdirectories, which are populated when script executes.


## Replication instructions

To replicate the pdf of this paper from scratch:
1. Unzip this folder to your computer.
2. Set your local file paths correctly in OptimalSodaTax_JEPMasterFile.do
3. Using Stata, do OptimalSodaTax_JEPMasterFile.do


## Additional details

Numbers related to the Nielsen PanelViews survey data from Allcott, Lockwood, Taubinsky (2019, QJE) rely on data which is proprietary, in keeping with the terms of Nielsen's data sharing restrictions, and must be obtained with Nielsen's approval. Therefore although the included script references that data set, the data itself is not included. 

